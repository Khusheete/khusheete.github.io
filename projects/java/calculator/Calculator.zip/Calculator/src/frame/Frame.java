/*
 * Copyright 2023 Souchet Ferdinand
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so.
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


package frame;

import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame ;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants ;

public class Frame extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	
	private JLabel result = new JLabel() ;
	private double lastNumber = 0 ;
	private char operator = ' ' ;
	
	public Frame() {
		this.setTitle("Calculator") ;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		this.setSize(300, 400) ;
		this.setResizable(false) ;
		
		{
			JPanel pan = new JPanel() ;
			FlowLayout f1 = new FlowLayout() ;
			f1.setVgap(20) ;
			pan.setLayout(f1) ;
			
			pan.setBackground(Color.LIGHT_GRAY) ;
			
			this.result.setPreferredSize(new Dimension(275, 40)) ;
			this.result.setFont(new Font("Arial", Font.BOLD, 26)) ;
			this.result.setForeground(Color.BLACK) ;
			this.result.setBorder(BorderFactory.createLineBorder(Color.black)) ;
			this.result.setHorizontalAlignment(SwingConstants.RIGHT);
			this.result.setText("0") ;
			pan.add(this.result) ;
			
			JPanel pan1 = new JPanel() ;
			pan1.setBackground(Color.LIGHT_GRAY) ;
			pan1.setPreferredSize(new Dimension(250, 200)) ;
			GridLayout g1 = new GridLayout(4, 3) ;
			g1.setHgap(10) ;
			g1.setVgap(10) ;
			pan1.setLayout(g1) ;
			
			for (int i = 1; i <= 9; i++) {
				Button b = new Button("" + i) ;
				b.addActionListener(this) ;
				pan1.add(b) ;
			}
			
			Button b = new Button(".") ;
			b.addActionListener(this) ;
			pan1.add(b) ;
			b = new Button("0") ;
			b.addActionListener(this) ;
			pan1.add(b) ;
			b = new Button("=") ;
			b.addActionListener(this) ;
			pan1.add(b) ;
			
			pan.add(pan1) ;
			
			JPanel pan2 = new JPanel() ;
			pan2.setBackground(Color.LIGHT_GRAY) ;
			pan2.setPreferredSize(new Dimension(275, 40)) ;
			GridLayout g2 = new GridLayout(1, 5) ;
			g2.setVgap(5) ;
			g2.setHgap(5) ;
			pan2.setLayout(g2) ;
			
			b = new Button("+") ;
			b.addActionListener(this) ;
			pan2.add(b) ;
			b = new Button("-") ;
			b.addActionListener(this) ;
			pan2.add(b) ;
			b = new Button("*") ;
			b.addActionListener(this) ;
			pan2.add(b) ;
			b = new Button("/") ;
			b.addActionListener(this) ;
			pan2.add(b) ;
			b = new Button("c") ;
			b.addActionListener(this) ;
			pan2.add(b) ;
			
			pan.add(pan2) ;
			
			
			this.setContentPane(pan) ;
		}
		
		this.setVisible(true) ;
	}
	
	public void actionPerformed(ActionEvent event) {
		char action = ((Button)event.getSource()).getLabel().toCharArray()[0] ;
		this.performAction(action) ;
	}
	
	
	public void performAction(char action) {
		if (action == '0' || action == '1' || action == '2' || action == '3' || action == '4' || action == '5' || action == '6' || action == '7' || action == '8' || action == '9' || action == '.') {
			String text = this.result.getText() ;
			if (!text.equals("0")) {
				this.result.setText(text + action) ;
			} else {
				this.result.setText(""+action);
			}
		} else
		if (action == '-' && this.result.getText().equals("0")) {
			this.result.setText("-");
		} else
		if (action == '+' && this.result.getText().equals("-")) {
			this.result.setText("0");
		} else
		if (action == 'c') {
			this.result.setText("0") ;
			this.operator = ' ' ;
			this.lastNumber = 0 ;
		} else 
		if (action == '+' || action == '-' || action == '/' || action == '*') {
			this.lastNumber = Double.parseDouble(this.result.getText()) ;
			this.result.setText("0") ;
			this.operator = action ;
		} else
		if (action == '=' && this.operator != ' ') {
			double nb2 = Double.parseDouble(this.result.getText()) ;
			double nb1 = this.lastNumber ;
			double rst = 0 ;
			switch (this.operator) {
			case '+':
				rst = nb1 + nb2 ;
				break ;
			case '-':
				rst = nb1 - nb2 ;
				break ;
			case '*':
				rst = nb1 * nb2 ;
				break ;
			case '/':
				rst = nb1 / nb2 ;
				break ;
			}
			this.result.setText(""+rst) ;
			this.operator = ' ' ;
			this.lastNumber = rst ;
		}
	}
}
