/*
 * Copyright 2023 Souchet Ferdinand
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so.
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


package frame;

import turtle.Turtle ;
import file.FileModifier ;

import javax.swing.JFrame ;
import javax.swing.JPanel ;
import java.awt.Graphics ;
import java.awt.Color ;
import java.util.ArrayList ;

public class Frame extends JFrame implements Runnable {
	ArrayList<Command> classes ;
	ArrayList<String> className ;
	ArrayList<String> funcs ;
	Panel pan ;
	
	Turtle t ;
	
	public Frame() {
		this.setSize(600, 600) ;
		this.setVisible(true) ;
		this.t = new Turtle() ;
		this.pan = new Panel() ;
		pan.setBackground(new Color(0, 0, 0)) ;
		this.setContentPane(pan) ;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
	}
	
	private boolean isBlanc(String s) {
		if (!s.isEmpty()) {
			for (char i : s.toCharArray()) {
				if (i != ' ' && i != '	')
					return false ;
			}
		}
		return true ;
	}
	
	public void reload() {
		this.classes = new ArrayList<Command>() ;
		this.className = new ArrayList<String>() ;
		this.funcs = new ArrayList<String>() ;
		FileModifier f = new FileModifier("src/funcs.data") ;
		String text = f.txt.in.read() ;
		String lg[] = text.split("\n") ;
		for (int i = 0; i < lg.length; i++) {
			funcs.add(lg[i].split(" ")[0]) ;
		}
		
		
		f = new FileModifier("src/logo.lg") ;
		text = f.txt.in.read() ;
		lg = text.split("\n") ;
		boolean inClass = false ;
		Command current = null ;
		for (int i = 0; i < lg.length; i++) { //Decode the 'logo.lg' file
			String str = lg[i] ;
			if (isBlanc(str))
				continue ;
			if (str.startsWith("to ") && !className.contains(str.split(" ")[1]) && !funcs.contains(str.split(" ")[1])) {
				this.classes.add(new Command()) ;
				this.className.add(str.split(" ")[1]) ;
				current = this.classes.get(this.classes.size() - 1) ;
				
				String[] args = str.split(" ")[2].split(",") ;
				for (int j = 0; j < args.length; j++) {
					args[j] = args[j].trim() ;
				}
				if (args[0].compareTo("null") != 0) {
					current.setArgumentsName(args);
				} else {
					current.noArguments() ;
				}
				inClass = true ;
				continue ;
			}
			if (str.startsWith("end")) {
				inClass = false ;
				continue ;
			}	
			if (inClass) {
				current.add(((str.contains("//"))? str.split(" //")[0] : str.trim()).replace("	","")) ;
			}
		}
	}
	
	
	public void run() {
		this.reload() ;
		this.pan.repaint() ;
	}
	
	private class Panel extends JPanel {
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g) ;
			g.setColor(new Color(0, 0, 0)) ;
			g.fillRect(0, 0, this.getWidth(), this.getHeight()) ;
			if (!classes.isEmpty()) {
				t.reset() ;
				t.setGraphics(g) ;
				int run = className.indexOf("run") ;
				if (run != -1) {
					classes.get(run).run() ;
				} else {
					System.err.println("No run function in the specified folder.") ;
				}
			}
		}
	}
	
	public class Command {
		private ArrayList<String> cmds ;
		private ArrayList<Int> i ;
		private ArrayList<Integer> maxI ;
		private ArrayList<Integer> forLine ;
		private ArrayList<Double> vars ;
		private ArrayList<String> varsName ;
		private ArrayList<String> argsName ;
		private int step ;
		
		public Command() {
			this.setup() ;
		}
		
		public Command(String[] cmd) {
			this.setup() ;
			this.add(cmd) ;
		}
		
		private void setup() {
			this.cmds = new ArrayList<String>() ;
			this.vars = new ArrayList<Double>() ;
			this.varsName = new ArrayList<String>() ;
			this.step = 0 ;
		}
		
		public void add(String cmd) {
			this.cmds.add(cmd) ;
		}
		
		public void add(String[] cmd) {
			for (String i : cmd) 
				cmds.add(i) ;
		}
		
		public void run() {
			this.i = new ArrayList<Int>() ;
			this.maxI = new ArrayList<Integer>() ;
			this.forLine = new ArrayList<Integer>() ;
			
			for (this.step = 0; this.step < this.cmds.size(); this.step++) {
				String cmd = this.cmds.get(this.step) ;
				double[] args = new double[cmd.split(" ").length - 1] ;
				if (cmd.startsWith("-")) {
					cmd = cmd.replace("-","") ;
					for (int i = 1; i < cmd.split(" ").length; i++) {
						args[i-1] = getValue(cmd.split(" ")[i]) ;
					}
					switch (cmd.split(" ")[0]) {
					case "forward":
						t.forward(args[0]);
						break ;
					case "angle":
						t.angle(args[0]);
						break ;
					case "right":
						t.right(args[0]);
						break ;
					case "left":
						t.left(args[0]);
						break ;
					case "set":
						t.set(args[0], args[1], args[2]);
						break ;
					case "color":
						t.color(new Color((int) args[0], (int) args[1], (int) args[2]));
						break ;
					case "penUp":
						t.penUp() ;
						break ;
					case "penDown":
						t.penDown() ;
						break ;
					}
					if (className.contains(cmd.split(" ")[0])) {
						int classID = className.indexOf(cmd.split(" ")[0]) ;
						Command call = classes.get(classID) ;
						if (call.haveArguments()) {
							call.call(args) ;
						} else {
							call.run() ;
						}
					}
				} else {
					if (cmd.split(" ")[0].compareTo("repeat") == 0) {
						this.forLine.add(this.step) ;
						this.maxI.add((int) getValue(cmd.split(" ")[1])) ;
						this.i.add(new Int(0)) ;
					}
					if (cmd.split(" ")[0].compareTo("}") == 0 && i.size() > 0) {
						Int I = this.i.get(this.i.size() - 1) ;
						I.increment() ;
						if (I.getValue() >= this.maxI.get(maxI.size() - 1)) {
							this.forLine.remove(this.forLine.size() - 1) ;
							this.i.remove(this.i.size() - 1) ;
							this.maxI.remove(this.maxI.size() - 1) ;
						} else {
							this.step = this.forLine.get(this.forLine.size() - 1) ;
						}
					}
				}
			}
		}
		
		private double getValue(String var) {
			double awnser = 0 ; 
			if (this.varsName.contains(var)) {
				awnser = this.vars.get(this.varsName.indexOf(var)) ;
			} else if (var.startsWith("#i")) {
				Int I = this.i.get(Integer.parseInt(var.split("i")[1])) ;
				awnser = I.getValue() ;
			} else {
				awnser = Double.parseDouble(var) ;
			}
			return awnser ;
		}
		
		private void setValue(String var, String nb) {
			double set = getValue(nb) ;
			if (this.varsName.contains(var)) {
				int varID = this.varsName.indexOf(var) ;
				double val = this.vars.get(varID) ;
				val = set ;
			} else {
				this.varsName.add(var) ;
				this.vars.add(set) ;
			}
		}
		
		private void setValue(String var, double nb) {
			if (this.varsName.contains(var)) {
				int varID = this.varsName.indexOf(var) ;
				double val = this.vars.get(varID) ;
				val = nb ;
			} else {
				this.varsName.add(var) ;
				this.vars.add(nb) ;
			}
		}
		
		public void setArgumentsName(String[] s) {
			this.varsName = new ArrayList<String>() ;
			this.argsName = new ArrayList<String>() ;
			for (String i : s) {
				this.argsName.add(i) ;
			}
		}
		
		public void call(double[] args) {
			this.vars = new ArrayList<Double>() ;
			this.varsName = this.argsName ;
			for (int i = 0; i < this.argsName.size(); i++) {
				this.vars.add(args[i]) ;
			}
			this.run() ;
		}
		
		public boolean haveArguments() {
			return (this.argsName.size() > 0) ;
		}
		
		public void noArguments() {
			this.argsName = new ArrayList<String>() ;
		}
		
		public String toString() {
			String result = "";
			for (int i = 0; i < this.cmds.size(); i++) {
				result += this.cmds.get(i) ;
				if (i < this.cmds.size() - 1) result += "\n" ;
			}
			return result ;
		}
	}
	
	private class Int {
		private int value ;
		
		public Int(int v) {
			this.value = v ;
		}
		
		public int getValue() {
			return this.value ;
		}
		
		public void increment() {
			this.value++ ;
		}
	}
}
