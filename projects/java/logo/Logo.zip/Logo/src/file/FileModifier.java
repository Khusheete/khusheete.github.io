/*
 * Copyright 2023 Souchet Ferdinand
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so.
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


package file;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.IntBuffer;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.LongBuffer;
import java.nio.DoubleBuffer;
import java.nio.ShortBuffer;
import java.nio.FloatBuffer;
import java.nio.channels.FileChannel;
import java.io.IOException;
import java.net.URI;


public class FileModifier extends File {

	public Text txt = new Text() ;
	public Data data = new Data() ;
	public Obj object = new Obj() ;
	public FileBuffer buffer = new FileBuffer() ;
	
	public FileModifier(String arg0) {
		super(arg0);
	}

	public FileModifier(URI arg0) {
		super(arg0);
	}

	public FileModifier(String arg0, String arg1) {
		super(arg0, arg1);
	}

	public FileModifier(File arg0, String arg1) {
		super(arg0, arg1);
	}
	
	private File get() {
		return (File) this ;
	}
	
	public void create() {
		try {
			createNewFile() ;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public class Text {
		private Text() {}
		
		public InputFunc in = new InputFunc() ;
		public OutputFunc out = new OutputFunc() ;
		
		public class InputFunc {
			private InputFunc() {}
		
			public BufferedInputStream Stream ;
		
			private void setup() {
				try {
					Stream = new BufferedInputStream(new FileInputStream(get())) ;
				} catch (FileNotFoundException e) {
					e.printStackTrace() ;
				}
			}
		
			public String read() {
				setup() ;
				try {
					byte content[] = Stream.readAllBytes() ;
					String r = "";
					for (byte i : content) {
						r += (char) i ; 
					}
					return r ;
				} catch (IOException e) {
					return "#Error\n-->\n\n"+e.getMessage()+"Caused by:\n"+e.getCause() ;
				} finally {
					try {
						Stream.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		
		
		
		}
	
		public class OutputFunc {
			private OutputFunc(){}
			public BufferedOutputStream Stream ;
		
			public void setup() {
				try {
					Stream = new BufferedOutputStream(new FileOutputStream(get())) ;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
		
			public void clear() {
				setup() ;
			}
		
			public void close() {
				try {
					Stream.close() ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
		
			public void load() {
				try {
					in.setup() ;
					byte b[] = in.Stream.readAllBytes() ;
					setup() ;
					Stream.write(b) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				} finally {
					try {
						in.Stream.close() ;
					} catch (IOException e){
						e.printStackTrace() ;
					}
				}
			}
		
		
		
		
			public void println(String s) {
				try {
					char c[] = s.toCharArray() ;
					byte b[] = new byte[c.length + 1] ;
					b[0] = (byte) '\n' ;
					for (int i = 1; i < c.length + 1; i++) {
						b[i] = (byte) c[i-1] ;
					}
					Stream.write(b) ;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		
			public void print(String s) {
				try {
					char c[] = s.toCharArray() ;
					byte b[] = new byte[c.length] ;
					for (int i = 1; i < c.length; i++) {
						b[i] = (byte) c[i] ;
					}
					Stream.write(b) ;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public class Data {

		private Data() {}
		
		public InputFunc in = new InputFunc() ;
		public OutputFunc out = new OutputFunc() ;
		
		public class InputFunc {
			private InputFunc() {}
			
			public DataInputStream Stream ;
			
			public void setup() {
				try {
					Stream = new DataInputStream(new BufferedInputStream(new FileInputStream(get()))) ;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
			
			public byte readByte() {
				try {
					return Stream.readByte() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return 0 ;
				}
			}
			
			public int readInt() {
				try {
					return Stream.readInt() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return 0 ;
				}
			}
			
			public char readChar() {
				try {
					return Stream.readChar() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return '\t' ;
				}
			}
			
			public long readLong() {
				try {
					return Stream.readLong() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return 0 ;
				}
			}
			
			public double readDouble() {
				try {
					return Stream.readDouble() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return 0 ;
				}
			}
			
			public boolean readBoolean() {
				try {
					return Stream.readBoolean() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return false ;
				}
			}
			
			public short readShort() {
				try {
					return Stream.readShort() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return 0 ;
				}
			}
			
			public float readFloat() {
				try {
					return Stream.readFloat() ;
				} catch (IOException e) {
					e.printStackTrace() ;
					return 0 ;
				}
			}
			
			public void close() {
				try {
					Stream.close() ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
		}
		
		public class OutputFunc {
			private OutputFunc() {}
			
			public DataOutputStream Stream ;
			
			public void setup() {
				try {
					Stream = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(get()))) ;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
			
			public void clear() {
				setup() ;
			}
			
			
			public void load() {
				try {
					in.setup() ;
					byte b[] = in.Stream.readAllBytes() ;
					setup() ;
					Stream.write(b) ;
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					in.close() ;
				}
			}
			
			public void close() {
				try {
					Stream.close() ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			
			public void writeByte(byte b) {
				try {
					Stream.writeByte(b) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void writeInt(int i) {
				try {
					Stream.writeInt(i) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void writeChar(char c) {
				try {
					Stream.writeChar(c) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void writeLong(long l) {
				try {
					Stream.writeLong(l) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void writeDouble(double d) {
				try {
					Stream.writeDouble(d) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void writeBoolean(boolean b) {
				try {
					Stream.writeBoolean(b) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void writeShort(short s) {
				try {
					Stream.writeShort(s) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void writeFloat(float f) {
				try {
					Stream.writeFloat(f) ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
		}
		
	}

	public class Obj {
		private Obj() {}
		
		public InputFunc in = new InputFunc() ;
		public OutputFunc out = new OutputFunc() ;
		
		public class InputFunc {
			private InputFunc() {}
			
			public ObjectInputStream Stream ;
			
			public void setup() {
				try {
					Stream = new ObjectInputStream(new DataInputStream(new BufferedInputStream(new FileInputStream(get())))) ;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			public void close() {
				try {
					Stream.close() ;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			public Object readObject() {
				try {
					return (Object) Stream.readObject() ;
				} catch (IOException e) {
					e.printStackTrace();
					return new Object() ;
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
					return new Object() ;
				}
			}
			
			
		}
		
		public class OutputFunc {
			private OutputFunc() {}
			
			public ObjectOutputStream Stream ;
			
			public void setup() {
				try {
					Stream = new ObjectOutputStream(new DataOutputStream(new BufferedOutputStream(new FileOutputStream(get())))) ;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			public void close() {
				try {
					Stream.close() ;
				} catch (IOException e) {
					e.printStackTrace() ;
				}
			}
			
			public void clear() {
				setup() ;
			}
			
			public void load() {
				try {
					in.setup() ;
					byte b[] = in.Stream.readAllBytes() ;
					setup() ;
					Stream.write(b);
				} catch (IOException e) {
					e.printStackTrace() ;
				} finally {
					in.close();
				}
			}
			
			public void writeObject(Object o) {
				try {
					Stream.writeObject(o) ;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public class FileBuffer {
		private FileBuffer() {}
		
		
		
		public InputFunc in = new InputFunc() ;
		public OutputFunc out = new OutputFunc() ;
		
		public class InputFunc {
			private InputFunc() {}
			
			public FileChannel fc ;
			public FileInputStream Stream ;
			
			private IntBuffer Int ;
			private ByteBuffer Byte ;
			private CharBuffer Char ;
			private LongBuffer Long ;
			private DoubleBuffer Double ;
			private ShortBuffer Short ;
			private FloatBuffer Float ;
			
			private int size ;
			
			private void setup() {
				try {
					Stream = new FileInputStream(get()) ;
					fc = Stream.getChannel() ;
					size = (int)fc.size();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			private void read() {
				setup() ;
				try {
					Byte = ByteBuffer.allocate(size) ;
					Byte.flip() ;
					fc.read(Byte) ;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			public byte[] readByte() {
				read() ;
				try {
					fc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				return Byte.array() ;
			}
			
			public int[] readInt() {
				read() ;
				Int = IntBuffer.allocate(size) ;
				Int = Byte.asIntBuffer() ;
				try {
					fc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				Int.flip() ;
				return Int.array() ;
			}
			
			public char[] readChar() {
				read() ;
				Char = CharBuffer.allocate(size) ;
				Char = Byte.asCharBuffer() ;
				try {
					fc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				Char.flip() ;
				return Char.array() ;
			}
			
			public long[] readLong() {
				read() ;
				Long = LongBuffer.allocate(size) ;
				Long = Byte.asLongBuffer() ;
				try {
					fc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				Long.flip() ;
				return Long.array() ;
			}
			
			public double[] readDouble() {
				read() ;
				Double = DoubleBuffer.allocate(size) ;
				Double = Byte.asDoubleBuffer() ;
				try {
					fc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				Double.flip() ;
				return Double.array() ;
			}
			
			public float[] readFloat() {
				read() ;
				Float = FloatBuffer.allocate(size) ;
				Float = Byte.asFloatBuffer() ;
				try {
					fc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				Float.flip() ;
				return Float.array() ;
			}
			
			public short[] readShort() {
				read() ;
				Short = ShortBuffer.allocate(size) ;
				Short = Byte.asShortBuffer() ;
				try {
					fc.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				Short.flip() ;
				return Short.array() ;
			}
		}
		
		public class OutputFunc {
			private OutputFunc() {}
			
			public FileChannel fc ;
			public FileOutputStream Stream ;
			
			private int size ;
			
			private void setup() {
				try {
					Stream = new FileOutputStream(get()) ;
					fc = Stream.getChannel() ;
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
			
			public void write(byte[] b) {
				setup() ;
				ByteBuffer buffer = ByteBuffer.wrap(b) ;
				try {
					fc.write(buffer) ;
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						fc.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			//TODO Not finished: make write for others primitives (int, char, long etc..)
		}
	}
}