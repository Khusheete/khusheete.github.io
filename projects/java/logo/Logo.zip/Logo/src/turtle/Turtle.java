/*
 * Copyright 2023 Souchet Ferdinand
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so.
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


package turtle;

import java.awt.Graphics ;
import java.awt.BasicStroke ; 
import java.awt.Graphics2D ;
import java.awt.Color ;

public class Turtle {
	private double x, y ;
	private double angle ;
	private boolean penDown ;
	private Color c = new Color(255, 255, 255) ;
	
	private double baseX, baseY ;
	private double baseAngle ;
	
	private Graphics2D g2 ;
	
	public Turtle(double x, double y, double angle) {
		this.baseX = x ;
		this.baseY = y ;
		this.baseAngle = angle ;
		this.reset() ;
	}
	
	public Turtle() {
		this.baseX = 0d ;
		this.baseY = 0d ;
		this.baseAngle = 0d ;
		this.reset() ;
	}
	
	public void reset() {
		this.c = new Color(255, 255, 255) ;
		this.penDown = true ;
		this.x = this.baseX ;
		this.y = this.baseY ;
		this.angle = this.baseAngle ;
	}
	
	public void left(double angle) {
		this.angle -= angle ;
		this.angle %= 360 ;
	}
	
	public void right(double angle) {
		this.angle += angle ;
		this.angle %= 360 ;
	}
	
	public void angle(double angle) {
		this.angle = angle ;
	}
	
	public void set(double x, double y, double angle) {
		this.baseX = x ;
		this.baseY = y ;
		this.baseAngle = angle ;
		this.x = this.baseX ;
		this.y = this.baseY ;
		this.angle = this.baseAngle ;
	}
	
	public void forward(double steps) {
		double lastX = x ;
		double lastY = y ;
		
		this.x += Math.cos(Math.toRadians(this.angle)) * steps ;
		this.y += Math.sin(Math.toRadians(this.angle)) * steps ;
		
		if (penDown) {
			this.g2.setColor(c) ;
			this.g2.setStroke(new BasicStroke(5)); ;
			this.g2.drawLine((int) lastX, (int) lastY, (int) this.x, (int) this.y);
		}
	}
	
	public void color(Color c) {
		this.c = c ;
	}
	
	public void penUp() {
		this.penDown = false ;
	}
	
	public void penDown() {
		this.penDown = true ;
	}
	
	public void setGraphics(Graphics g) {
		this.g2 = (Graphics2D) g ;
	}
}
