/*
 * Copyright 2023 Souchet Ferdinand
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so.
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.util.List;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import epicycle.Complex;
import epicycle.Epicycle;


@SuppressWarnings("serial")
public class Frame extends JFrame {
	private Epicycle epicycle;
	private Panel pan;
	private byte mode;
	private List<Complex> pos;
	
	private long time = System.currentTimeMillis();
	
	private final int width = 600, height = 600;
	
	Frame() {
		this.setSize(this.width + 18, this.height + 40);
		this.setVisible(true);
		this.setTitle("Epicycles");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		
		this.pan = new Panel();
		pan.setBackground(new Color(255, 255, 255));
		this.setContentPane(pan);
		
//		this.addMouseListener(new Mouse());
//		this.addMouseMotionListener(new Mouse());
		
		this.reset();
		
		// PI <3 !!
		this.pos.add(new Complex(38  , 613 , Complex.CARTESIAN));
		this.pos.add(new Complex(120 , 422 , Complex.CARTESIAN));
		this.pos.add(new Complex(237 , 191 , Complex.CARTESIAN));
		this.pos.add(new Complex(450 , 79  , Complex.CARTESIAN));
		this.pos.add(new Complex(611 , 55  , Complex.CARTESIAN));
		this.pos.add(new Complex(908 , 40  , Complex.CARTESIAN));
		this.pos.add(new Complex(1296, 37  , Complex.CARTESIAN));
		this.pos.add(new Complex(1722, 39  , Complex.CARTESIAN));
		this.pos.add(new Complex(2076, 41  , Complex.CARTESIAN));
		this.pos.add(new Complex(2079, 352 , Complex.CARTESIAN));
		this.pos.add(new Complex(1590, 350 , Complex.CARTESIAN));
		this.pos.add(new Complex(1528, 1346, Complex.CARTESIAN));
		this.pos.add(new Complex(1600, 1608, Complex.CARTESIAN));
		this.pos.add(new Complex(1712, 1676, Complex.CARTESIAN));
		this.pos.add(new Complex(1840, 1671, Complex.CARTESIAN));
		this.pos.add(new Complex(2002, 1423, Complex.CARTESIAN));
		this.pos.add(new Complex(2079, 1422, Complex.CARTESIAN));
		this.pos.add(new Complex(1985, 1774, Complex.CARTESIAN));
		this.pos.add(new Complex(1694, 2001, Complex.CARTESIAN));
		this.pos.add(new Complex(1477, 1996, Complex.CARTESIAN));
		this.pos.add(new Complex(1220, 1750, Complex.CARTESIAN));
		this.pos.add(new Complex(1219, 1587, Complex.CARTESIAN));
		this.pos.add(new Complex(1316, 345 , Complex.CARTESIAN));
		this.pos.add(new Complex(867 , 345 , Complex.CARTESIAN));
		this.pos.add(new Complex(709 , 1730, Complex.CARTESIAN));
		this.pos.add(new Complex(529 , 1988, Complex.CARTESIAN));
		this.pos.add(new Complex(256 , 1927, Complex.CARTESIAN));
		this.pos.add(new Complex(201 , 1775, Complex.CARTESIAN));
		this.pos.add(new Complex(632 , 821 , Complex.CARTESIAN));
		this.pos.add(new Complex(647 , 347 , Complex.CARTESIAN));
		this.pos.add(new Complex(384 , 366 , Complex.CARTESIAN));
		this.pos.add(new Complex(223 , 472 , Complex.CARTESIAN));
		this.pos.add(new Complex(112 , 641 , Complex.CARTESIAN));
		
		for (int i = 0; i < this.pos.size(); i++) {
			Complex c = this.pos.get(i);
			this.pos.set(i, 
					new Complex(
							300.0 * (c.real()      / 2116d - 0.5),
							300.0 * (c.imaginary() / 2048d - 0.5),
							Complex.CARTESIAN
					)
			);
		}
		
		
		mode = 1;
		epicycle.setFromComplexList(pos);
	}
	
	public void reset() {
		this.epicycle = new Epicycle();
		this.mode = 0;
		this.pos = new ArrayList<Complex>();
	}
	
	
	public void run() {
		while (true) {
			if (10000d / this.pos.size() + this.time < System.currentTimeMillis() && this.mode == 1) {
				this.repaint();
				this.time = System.currentTimeMillis();
			}
			if (this.mode == 0) {
				this.repaint();
			}
		}
	}
	
	
	
	private class Panel extends JPanel {
		List<Complex> path = new ArrayList<Complex>();
		
		@Override
		public void paintComponent(Graphics g) {
			g.setColor(new Color(255, 255, 255));
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			if (mode == 1) {
					epicycle.paint(g, width, height);
					epicycle.step();
					this.path.add(epicycle.getPos());
					if (epicycle.ended()) {
						this.path = new ArrayList<Complex>();
					}
					
					g.setColor(new Color(100, 100, 100));
					for (int i = 1; i < path.size(); i++) {
						Complex c0 = path.get(i - 1);
						Complex c1 = path.get(i);
						g.drawLine((int)c0.real() + width/2, (int)c0.imaginary() + height/2, (int)c1.real() + width/2, (int)c1.imaginary() + height/2);
					}
			} else {
				if (this.path.size() > 0) this.path = new ArrayList<Complex>();
				g.setColor(new Color(100, 100, 100));
				for (int i = 1; i < pos.size(); i++) {
					Complex c0 = pos.get(i - 1);
					Complex c1 = pos.get(i);
					g.drawLine((int)c0.real() + width/2, (int)c0.imaginary() + height/2, (int)c1.real() + width/2, (int)c1.imaginary() + height/2);
				}
			}
		}
	}
	
	
	private class Mouse extends MouseAdapter {
		@Override
		public void mousePressed(MouseEvent e) {
			reset();
		}
		
		@Override
		public void mouseDragged(MouseEvent e) {
			pos.add(new Complex(e.getXOnScreen() - width/2, e.getYOnScreen() - height/2, Complex.CARTESIAN));
		}
		
		@Override
		public void mouseReleased(MouseEvent e) {
			mode = 1;
			epicycle.setFromComplexList(pos);
		}
	}
}
