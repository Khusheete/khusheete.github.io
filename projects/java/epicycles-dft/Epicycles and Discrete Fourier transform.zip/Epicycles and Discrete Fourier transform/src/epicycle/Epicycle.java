/*
 * Copyright 2023 Souchet Ferdinand
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so.
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


package epicycle;

import java.awt.Graphics;
import java.awt.Color ;
import java.util.List ;
import java.util.stream.Collectors;


public class Epicycle {
	List<Circle> circles ;
	private double time ;
	
	public Epicycle() {}
	
	public void setFromComplexList(List<Complex> pos) {
		this.time = 0 ;
		Circle[] tempCircles = new Circle[pos.size()] ;
		
		for (int i = 0; i < tempCircles.length; i++) {
			Complex c = new Complex() ;
			
			for (int j = 0; j < pos.size(); j++) {
				c.add(Complex.multiplyComplex(pos.get(j), new Complex(Math.cos(2d * Math.PI * i * j / tempCircles.length), -Math.sin(2d * Math.PI * i * j / tempCircles.length), Complex.CARTESIAN))) ;
			}
			c.setValue(c.real() / pos.size(), c.imaginary() / pos.size(), Complex.CARTESIAN) ;
			tempCircles[i] = new Circle(c.radius(), i, c.angle()) ;
		}
		this.circles = List.of(tempCircles).stream().sorted((x, y) -> (int)(y.radius - x.radius)).collect(Collectors.toList()) ;
	}
	
	public void paint(Graphics g, int width, int height) {
		final Color BLUE = new Color(0, 0, 255) ;
		final Color DARK_CYAN = new Color(0, 139, 139) ;
		Complex trans = new Complex(width/2, height/2, Complex.CARTESIAN) ;
		for (Circle c : this.circles) {
			g.setColor(BLUE) ;
			g.drawOval((int)trans.real() - (int)c.radius, (int)trans.imaginary() - (int)c.radius, (int)c.radius * 2, (int)c.radius * 2) ;
			g.setColor(DARK_CYAN) ;
			Complex temp = Complex.addComplex(trans, c.getPos(this.time)) ;
			g.drawLine((int)trans.real(), (int)trans.imaginary(), (int)temp.real(), (int)temp.imaginary()) ;
			trans = temp ;
		}
	}
	
	public Complex getPos() {
		return this.circles.stream().map((x) -> x.getPos(this.time)).reduce(new Complex(), (x, y) -> Complex.addComplex(x, y)) ;
	}

	
	public void step() {
		this.time += Math.PI * 2d / this.circles.size() ;
	}
	
	public boolean ended() {
		if (this.time > Math.PI * 2d) {
			this.time = 0 ;
			return true ;
		} else {
			return false ;
		}
	}
}
