/*
 * Copyright 2023 Souchet Ferdinand
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so.
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


package epicycle;


public class Complex {
	private Real a ;
	private Imaginary b ;
	
	public final static byte CARTESIAN = 0 ;
	public final static byte POLAR = 1 ;
	
	public Complex() {
		this.a = new Real(0) ;
		this.b = new Imaginary(0) ;
	}
	
	public Complex(double val1, double val2, byte coordSystem) {
		if (coordSystem == Complex.CARTESIAN) {
			this.a = new Real(val1) ;
			this.b = new Imaginary(val2) ;
		} else if (coordSystem == Complex.POLAR) {
			this.a = new Real(val1 * Math.cos(val2)) ;
			this.b = new Imaginary(val1 * Math.sin(val2)) ;
		}
	}
	
	public Complex(Real val1, Imaginary val2) {
		this.a = new Real(val1.getValue()) ;
		this.b = new Imaginary(val2.getValue()) ;
	}
	//setValue
	public void setValue(double val1, double val2, byte coordSystem) {
		if (coordSystem == Complex.CARTESIAN) {
			this.a.setValue(val1) ;
			this.b.setValue(val2) ;
		} else if (coordSystem == Complex.POLAR) {
			this.a.setValue(val1 * Math.cos(val2)) ;
			this.b.setValue(val1 * Math.sin(val2)) ;
		}
	}
	public void setValue(Real val1, Imaginary val2) {
		this.a.setValue(val1.getValue()) ;
		this.b.setValue(val2.getValue()) ;
	}
	public void setValue(Complex c) {
		this.a.setValue(c.real()) ;
		this.b.setValue(c.imaginary()) ;
	}
	
	
	
	//radius
	public double radius() {
		return Math.sqrt(Math.pow(this.real(), 2) + Math.pow(this.imaginary(), 2)) ;
	}
	
	//angle
	public double angle() {
		double t = 0;
	    double dist1 = this.radius(), dist2 = Math.abs(this.real()) ;
	    
	    if (dist1 != 0) t = Math.acos(dist2/dist1) ;

	    if (this.real() > 0 && this.imaginary() < 0) {
	      t = Math.PI * 2 - t ;
	    } else if (this.real() > 0 && this.imaginary() > 0) {
	      //Do nothing
	    } else if (this.real() < 0 && this.imaginary() > 0) {
	      t = Math.PI - t ;
	    } else if (this.real() < 0 && this.imaginary() < 0) {
	      t = Math.PI + t ;
	    } else if (this.real() == 0 && this.imaginary() < 0) {
	      t = Math.PI * 3 / 2 ;
	    } else if (this.real() == 0 && this.imaginary() > 0) {
	      t = Math.PI / 2 ;
	    } else if (this.real() < 0 && this.imaginary() == 0) {
	      t = Math.PI ;
	    } else if (this.real() > 0 && this.imaginary() == 0) {
	      t = 0 ;
	    }
	    return t ;
	}
	
	//imaginary
	public double imaginary() {
		return this.b.getValue() ;
	}
	
	//real
	public double real() {
		return this.a.getValue() ;
	}
	
	//toString 
	public String toString() {
		return ((this.real() < 0) ? "- " : "") + Math.abs(this.real()) + ((this.imaginary() < 0) ? " - " : " + ") + Math.abs(this.imaginary()) + " i";
	}
	
	//toString
	public String toString(byte coordSystem) {
		if (coordSystem == Complex.CARTESIAN) {
			return ((this.real() < 0) ? "- " : "") + Math.abs(this.real()) + ((this.imaginary() < 0) ? " - " : " + ") + Math.abs(this.imaginary()) + " i";
		} else if (coordSystem == Complex.POLAR) {
			return this.radius() + " < " + this.angle() ;
		}
		
		return null ;
	}
	
	//Copy
	public Complex copy() {
		return new Complex(this.real(), this.imaginary(), Complex.CARTESIAN) ;
	}
	
	//CompareTo
	public double compareTo(Complex other) {
		return (this.real() + this.imaginary()) - (other.real() + other.imaginary()) ;
	}
	
	
	
	//Add
	public void add(Complex... others) {
		Complex[] sum = new Complex[others.length + 1] ;
		for (int i = 0; i < others.length; i++) sum[i] = others[i] ;
		sum[sum.length-1] = this ;
		this.setValue(Complex.addComplex(sum)) ;
	}
	public void add(Real... numbers) {
		this.setValue(Complex.addComplex(this, numbers)) ;
	}
	public void add(Imaginary... numbers) {
		this.setValue(Complex.addComplex(this, numbers)) ;
	}
	
	
	//Subtract
	public void subtract(Complex other) {
		this.setValue(Complex.subtractComplex(this, other)) ;
	}
	public void subtract(Real number) {
		this.setValue(Complex.subtractComplex(this, number)) ;
	}
	public void subtract(Imaginary number) {
		this.setValue(Complex.subtractComplex(this, number)) ;
	}
	
	//Multiply
	public void multiply(Real... number) {
		this.setValue(Complex.multiplyComplex(this, number)) ;
	}
	public void multiply(Imaginary... number) {
		this.setValue(Complex.multiplyComplex(this, number)) ;
	}
	public void multiply(Complex... others) {
		Complex[] product = new Complex[others.length + 1] ;
		for (int i = 0; i < others.length; i++) product[i] = others[i] ;
		product[product.length-1] = this ;
		this.setValue(Complex.multiplyComplex(product)) ;
	}
	
	//pow
	public void pow(Real number) {
		this.setValue(Complex.powComplex(this, number));
	}
	public void pow(Imaginary number) {
		this.setValue(Complex.powComplex(this, number)) ;
	}
	public void pow(Complex number) {
		this.setValue(Complex.powComplex(this, number)) ;
	}
	
	//root
	public void root(Real number) {
		this.setValue(Complex.rootComplex(this, number)) ;
	}
	public void root(Imaginary number) {
		this.setValue(Complex.rootComplex(this, number)) ;
	}
	public void root(Complex number) {
		this.setValue(Complex.rootComplex(this, number)) ;
	}
	
	
	
	
	/* 
	 */
	public static Complex addComplex(Complex... numbers) {
		Complex result = new Complex() ;
		for (Complex c : numbers) {
			result.a.add(c.real()) ;
			result.b.add(c.imaginary()) ;
		}
		return result ;
	}
	public static Complex addComplex(Complex number, Real... values) {
		Complex result = number.copy() ;
		for (Real val : values) {
			result.a.add(val.getValue()) ;
		}
		return result ;
	}
	public static Complex addComplex(Complex number, Imaginary... values) {
		Complex result = number.copy() ;
		for (Imaginary val : values) {
			result.b.add(val.getValue()) ;
		}
		return result ;
	}
	
	
	/* 
	 */
	public static Complex subtractComplex(Complex nb1, Complex nb2) {
		Complex result = nb1.copy() ;
		result.a.subtract(nb2.real()) ;
		result.b.subtract(nb2.imaginary()) ;
		return result ;
	}
	public static Complex subtractComplex(Complex nb1, Real nb2) {
		Complex result = nb1.copy() ;
		result.a.subtract(nb2.getValue()) ;
		return result ;
	}
	public static Complex subtractComplex(Complex nb1, Imaginary nb2) {
		Complex result = nb1.copy() ;
		result.b.subtract(nb2.getValue()) ;
		return result ;
	}
	
	
	/*
	 */
	public static Complex multiplyComplex(Complex number, Real... values) {
		Complex result = number.copy() ;
		for (Real val : values) {
			result.a.multiply(val.getValue()) ;
			result.b.multiply(val.getValue()) ;
		}
		return result ;
	}
	public static Complex multiplyComplex(Complex number, Imaginary... values) {
		Complex result = number.copy() ;
		for (Imaginary val : values) {
			double temp = result.real() ;
			result.a.setValue((-result.imaginary()) * val.getValue()) ;
			result.b.setValue(temp * val.getValue()) ;
		}
		return result ;
	}
	public static Complex multiplyComplex(Complex... numbers) {
		Complex result = numbers[0].copy() ;
		for (int i = 1; i < numbers.length; i++) {
			double tempA = (result.real() * numbers[i].real()) - (result.imaginary() * numbers[i].imaginary()) ;
			double tempB = (result.real() * numbers[i].imaginary()) + (result.imaginary() * numbers[i].real()) ;
			result.setValue(tempA, tempB, Complex.CARTESIAN) ;
		}
		return result ;
	}
	
	/*
	 */
	public static Complex powComplex(Complex number, Real value) {
		Complex result = number.copy() ;
		result.setValue(Math.pow(result.radius(), value.getValue()), value.getValue() * result.angle(), Complex.POLAR) ;
		return result ;
	}
	public static Complex powComplex(Complex number, Imaginary value) {
		Complex result = number.copy() ;
		result.setValue(Math.pow(Math.E, (-result.angle()) * value.getValue()), value.getValue() * Math.log(result.radius()), Complex.POLAR) ;
		return result ;
	}
	public static Complex powComplex(Complex nb1, Complex nb2) {
		Complex p1 = new Complex(Math.pow(nb1.radius(), nb2.real()), 0, Complex.CARTESIAN) ;
	    Complex p2 = new Complex(nb1.radius(), 0, Complex.CARTESIAN) ;
	    p2.pow(nb2.b) ;
	    Complex p3 = new Complex(1, nb1.angle() * nb2.real(), Complex.POLAR) ;
	    Complex p4 = new Complex(Math.pow(Math.E, -(nb2.imaginary() * nb1.angle())), 0, Complex.CARTESIAN) ;
	    Complex result = Complex.multiplyComplex(p1, p2, p3, p4) ;

	    return result ;
	}
	
	/*
	 */
	public static Complex rootComplex(Complex nb1, Complex nb2) {
		Complex result = nb1.copy() ;
	    Complex temp = nb2.copy() ;
	    temp.pow(new Complex.Real(-1)) ;
	    result.pow(temp) ;
	    return result ;
	}
	public static Complex rootComplex(Complex nb1, Real nb2) {
		Complex result = nb1.copy() ;
	    Complex temp = new Complex(nb2.getValue(), 0, Complex.CARTESIAN) ;
	    temp.pow(new Complex.Real(-1)) ;
	    result.pow(temp) ;
	    return result ;
	}
	public static Complex rootComplex(Complex nb1, Imaginary nb2) {
		Complex result = nb1.copy() ;
	    Complex temp = new Complex(0, nb2.getValue(), Complex.CARTESIAN) ;
	    temp.pow(new Complex.Real(-1)) ;
	    result.pow(temp) ;
	    return result ;
	}
	
	/*
	 */
	public static Complex ln(Complex nb) {
		Complex result = new Complex(Math.log(nb.radius()), nb.angle(), Complex.CARTESIAN) ;
		return result ;
	}
	public static Complex log10(Complex nb) {
		Complex result = new Complex(Math.log10(nb.radius()), nb.angle() * Math.log10(Math.E), Complex.CARTESIAN) ;
		return result ;
	}
	
	
	
	
	
	
	public static class Imaginary {
		private double value ;
		
		public Imaginary(double value) {
			this.value = value ;
		}
		
		public void setValue(double value) {
			this.value = value ;
		}
		
		public double getValue() {
			return this.value ;
		}
		
		public void add(double value) {
			this.value += value ;
		}
		
		public void subtract(double value) {
			this.value -= value ;
		}
		
		public void multiply(double value) {
			this.value *= value ;
		}
		
		public String toString() {
			return ((this.value < 0) ? "- " : "") + Math.abs(this.value) + " i";
		}
	}
	
	public static class Real {
		private double value ;
		
		public Real(double value) {
			this.value = value ;
		}
		
		public void setValue(double value) {
			this.value = value ;
		}
		
		public double getValue() {
			return this.value ;
		}
		
		public void add(double value) {
			this.value += value ;
		}
		
		public void subtract(double value) {
			this.value -= value ;
		}
		
		public void multiply(double value) {
			this.value *= value ;
		}
		
		public String toString() {
			return ((this.value < 0) ? "- " : "") + Math.abs(this.value);
		}
	}
}
