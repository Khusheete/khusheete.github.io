/*
Copyright 2023 Souchet Ferdinand

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the “Software”), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

use std::cmp::min;
use std::process::{Command, Stdio};
use std::sync::mpsc;
use std::thread;
use std::vec::Vec;

use std::io;
use std::io::Write;

static PROCESSES: u16 = 16;

fn main() {
    let step: u16 = 255u16 / PROCESSES;
    let mut handles = Vec::new();
    let (tx, rx) = mpsc::channel();
    let mut th_nb: usize = 0;

    for i in (0..256).step_by(step as usize) {
        th_nb += 1;
        let txn = mpsc::Sender::clone(&tx);
        handles.push(thread::spawn(move || {
            for j in i..min(i + step, 255u16) {
                if j == 0 {
                    continue; //we do not need to ping gateway
                }
                let addr: String = format!("192.168.1.{}", j);
                let exists: bool = scan(&addr);
                if exists {
                    txn.send(Message::Ok(addr)).unwrap();
                } else {
                    txn.send(Message::Failed(addr)).unwrap();
                }
            }
            txn.send(Message::Finished).unwrap();
        }));
    }

    let mut addr_scaned: u16 = 0;
    while th_nb > 0 {
        match rx.recv().unwrap() {
            Message::Ok(addr) => {
                println!("\x1b[38;2;0;255;0m{:40}\x1b[m", addr);
                addr_scaned += 1;
            }
            Message::Failed(_) => {
                //println!("\x1b[38;2;255;0;0m{}\x1b[m", addr);
                addr_scaned += 1;
            }
            Message::Finished => {
                th_nb -= 1;
            }
        }
        print!("Scanning <");
        let pscaned: u16 = (addr_scaned as f64 / 255f64 * 20f64) as u16;
        for _ in 0..=pscaned {
            print!("=");
        }
        for _ in 0..(20 - pscaned) {
            print!("-");
        }
        print!(">\r");

        io::stdout().flush().unwrap();
    }

    //and join to end
    for h in handles {
        h.join().unwrap();
    }
}

enum Message {
    Ok(String),
    Failed(String),
    Finished,
}

//scan an ip and return true if it exists
fn scan(addr: &String) -> bool {
    let exit_status = Command::new("ping")
        .args(vec!["-c", "1", addr])
        .stdout(Stdio::null())
        .spawn()
        .expect("could not start ping")
        .wait()
        .unwrap();

    match exit_status.code() {
        Some(e) => {
            if e == 0 {
                return true;
            }
        }
        None => {}
    }
    return false;
}
